package me.xlui.im.message;

/**
 * 浏览器向服务端发送的消息应该用此类接受
 */
public class Message {
    private String name;

    public String getName() {
        return name;
    }
}
